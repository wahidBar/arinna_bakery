<header class="bg-[#FFFBF3]/90 backdrop-blur border-b border-amber-100 sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-4">
        <div class="flex items-center justify-between h-20">

            {{-- Logo --}}
            <a href="{{ route('home') }}" class="flex items-center gap-2.5 shrink-0 group">
                <span class="flex items-center justify-center w-10 h-10 rounded-full bg-amber-700 text-amber-50 shadow-sm group-hover:bg-amber-800 transition">
                    <i class="fa-solid fa-wheat-awn text-sm"></i>
                </span>
                <span class="font-display text-xl font-semibold text-stone-900 leading-tight">Arinna Hidayah <span class="text-amber-700">Bakery</span></span>
            </a>

            {{-- Menu navbar dinamis dari tabel `menus` --}}
            <nav class="hidden md:flex items-center gap-8">
                @foreach (\App\Models\Menu::where('is_active', true)->orderBy('sort_order')->get() as $menu)
                    <a href="{{ $menu->url }}"
                       @if ($menu->open_new_tab) target="_blank" @endif
                       class="text-sm font-semibold text-stone-600 hover:text-amber-700 transition">
                        {{ $menu->label }}
                    </a>
                @endforeach
            </nav>

            {{-- Search bar (live search AJAX) --}}
            <div class="hidden lg:block relative w-64">
                <i class="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-stone-400 text-xs"></i>
                <input
                    type="text"
                    id="navbar-search"
                    placeholder="Cari produk..."
                    class="w-full bg-white border border-amber-100 rounded-full pl-10 pr-4 py-2.5 text-sm placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-transparent transition"
                >
                <div id="navbar-search-results" class="hidden absolute mt-2 w-full bg-white border border-amber-100 rounded-2xl shadow-xl max-h-80 overflow-y-auto overflow-hidden"></div>
            </div>

            {{-- Icon keranjang + auth --}}
            <div class="flex items-center gap-5">
                @auth
                    <a href="{{ route('cart.index') }}" class="relative w-10 h-10 flex items-center justify-center rounded-full hover:bg-amber-100/70 transition">
                        <i class="fa-solid fa-basket-shopping text-stone-700"></i>
                        <span id="cart-badge" class="absolute -top-1 -right-1 bg-amber-700 text-white text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center ring-2 ring-[#FFFBF3]">0</span>
                    </a>

                    <div class="relative group">
                        <button class="flex items-center gap-2 text-sm font-semibold text-stone-700">
                            <span class="w-8 h-8 rounded-full bg-amber-100 text-amber-800 flex items-center justify-center text-xs font-bold">
                                {{ strtoupper(substr(auth()->user()->name, 0, 1)) }}
                            </span>
                            <span class="hidden xl:inline">{{ auth()->user()->name }}</span>
                            <i class="fa-solid fa-chevron-down text-[10px] text-stone-400"></i>
                        </button>
                        <div class="hidden group-hover:block absolute right-0 top-full pt-2 w-48">
                            <div class="bg-white border border-amber-100 rounded-2xl shadow-xl overflow-hidden py-1.5">
                                <a href="{{ route('orders.index') }}" class="flex items-center gap-2.5 px-4 py-2.5 text-sm font-medium text-stone-600 hover:bg-amber-50 hover:text-amber-800 transition">
                                    <i class="fa-solid fa-receipt w-4 text-stone-400"></i> Pesanan Saya
                                </a>
                                @if (auth()->user()->isAdmin())
                                    <a href="{{ route('admin.dashboard') }}" class="flex items-center gap-2.5 px-4 py-2.5 text-sm font-medium text-stone-600 hover:bg-amber-50 hover:text-amber-800 transition">
                                        <i class="fa-solid fa-gauge w-4 text-stone-400"></i> Dashboard Admin
                                    </a>
                                @endif
                                <form method="POST" action="{{ route('logout') }}">
                                    @csrf
                                    <button type="submit" class="w-full flex items-center gap-2.5 text-left px-4 py-2.5 text-sm font-medium text-rose-600 hover:bg-rose-50 transition">
                                        <i class="fa-solid fa-arrow-right-from-bracket w-4"></i> Keluar
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                @else
                    <a href="{{ route('login') }}" class="text-sm font-semibold text-stone-700 hover:text-amber-700 transition">Masuk</a>
                    <a href="{{ route('register') }}" class="text-sm font-semibold bg-amber-700 text-white px-5 py-2.5 rounded-full hover:bg-amber-800 shadow-sm transition">Daftar</a>
                @endauth
            </div>
        </div>
    </div>
</header>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function () {
    // Update badge jumlah cart secara live
    @auth
    fetch("{{ route('cart.count') }}")
        .then(res => res.json())
        .then(data => {
            document.getElementById('cart-badge').textContent = data.cart_count;
        });
    @endauth

    // Live search navbar
    const searchInput = document.getElementById('navbar-search');
    const resultsBox = document.getElementById('navbar-search-results');
    let debounceTimer;

    searchInput?.addEventListener('input', function () {
        clearTimeout(debounceTimer);
        const q = this.value.trim();

        if (q.length < 2) {
            resultsBox.classList.add('hidden');
            return;
        }

        debounceTimer = setTimeout(() => {
            fetch(`{{ route('products.search') }}?q=${encodeURIComponent(q)}`)
                .then(res => res.json())
                .then(products => {
                    if (products.length === 0) {
                        resultsBox.innerHTML = '<p class="p-4 text-sm text-stone-500">Produk tidak ditemukan.</p>';
                    } else {
                        resultsBox.innerHTML = products.map(p => `
                            <a href="/products/${p.slug}" class="flex items-center gap-3 p-3 hover:bg-amber-50 border-b border-amber-50 last:border-0">
                                <span class="text-sm font-medium text-stone-700">${p.name}</span>
                            </a>
                        `).join('');
                    }
                    resultsBox.classList.remove('hidden');
                });
        }, 300);
    });
});

// Helper global untuk update badge cart dari halaman lain (dipanggil setelah AJAX add to cart)
function refreshCartBadge() {
    fetch("{{ route('cart.count') }}")
        .then(res => res.json())
        .then(data => {
            const badge = document.getElementById('cart-badge');
            if (badge) badge.textContent = data.cart_count;
        });
}
</script>
@endpush
