@php
    $p = $product ?? null;
    $img = $p && ($p->thumbnail ?? $p->image) ? asset('storage/' . ($p->thumbnail ?? $p->image)) : asset('images/placeholder.png');
    $title = $p->name ?? ($p->title ?? 'Produk');
    $price = $p->price ?? 0;
    $slug = $p->slug ?? null;
    $id = $p->id ?? 0;
@endphp

<div class="group overflow-hidden rounded-2xl border border-amber-100 bg-white shadow-sm hover:shadow-lg hover:-translate-y-0.5 transition duration-300">
    <a href="{{ $slug ? route('products.show', $slug) : '#' }}" class="block">
        <div class="h-48 bg-amber-50 overflow-hidden">
            <img src="{{ $img }}" alt="{{ $title }}" class="w-full h-full object-cover group-hover:scale-105 transition duration-300">
        </div>
    </a>
    <div class="p-4">
        <h3 class="font-display text-sm font-semibold text-stone-900 leading-tight">{{ $title }}</h3>
        @if(isset($p->short_description))
            <p class="text-xs text-stone-500 mt-1 line-clamp-2">{{ $p->short_description }}</p>
        @endif

        <div class="mt-3 flex items-center justify-between gap-3">
            <div class="text-amber-700 font-bold">
                Rp {{ number_format($price, 0, ',', '.') }}
            </div>

            <div class="flex items-center gap-2">
                <button onclick="quickAddToCart({{ $id }})" class="inline-flex items-center gap-1.5 bg-amber-700 hover:bg-amber-800 text-white px-3.5 py-1.5 rounded-full text-xs font-semibold shadow-sm transition">
                    <i class="fa-solid fa-plus text-[10px]"></i>
                    Keranjang
                </button>

                <a href="{{ $slug ? route('products.show', $slug) : '#' }}" class="text-xs font-semibold text-stone-500 hover:text-amber-700 transition">Lihat</a>
            </div>
        </div>
    </div>
</div>
