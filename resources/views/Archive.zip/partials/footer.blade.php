@php
    $settings = \App\Models\SiteSetting::pluck('value', 'key');
@endphp

<footer class="bg-stone-900 text-stone-300 mt-20">
    <div class="max-w-7xl mx-auto px-4 py-14 grid grid-cols-1 md:grid-cols-3 gap-10">

        <div>
            <div class="flex items-center gap-2.5 mb-4">
                <span class="flex items-center justify-center w-9 h-9 rounded-full bg-amber-700 text-amber-50">
                    <i class="fa-solid fa-wheat-awn text-sm"></i>
                </span>
                <h3 class="font-display text-white font-semibold text-lg">{{ $settings['site_name'] ?? 'Arinna Hidayah Bakery' }}</h3>
            </div>
            <p class="text-sm leading-relaxed text-stone-400">
                Bakery & pastry rumahan dengan bahan pilihan, dibuat fresh setiap hari untuk momen spesial Anda.
            </p>
            <div class="flex gap-3 mt-5">
                @if (!empty($settings['instagram']))
                    <a href="{{ $settings['instagram'] }}" target="_blank" class="w-9 h-9 flex items-center justify-center rounded-full bg-stone-800 text-stone-300 hover:bg-amber-800 hover:text-white transition">
                        <i class="fa-brands fa-instagram"></i>
                    </a>
                @endif
                @if (!empty($settings['facebook']))
                    <a href="{{ $settings['facebook'] }}" target="_blank" class="w-9 h-9 flex items-center justify-center rounded-full bg-stone-800 text-stone-300 hover:bg-amber-800 hover:text-white transition">
                        <i class="fa-brands fa-facebook-f"></i>
                    </a>
                @endif
                @if (!empty($settings['tiktok']))
                    <a href="{{ $settings['tiktok'] }}" target="_blank" class="w-9 h-9 flex items-center justify-center rounded-full bg-stone-800 text-stone-300 hover:bg-amber-800 hover:text-white transition">
                        <i class="fa-brands fa-tiktok"></i>
                    </a>
                @endif
            </div>
        </div>

        <div>
            <h4 class="text-white font-semibold mb-4 text-sm uppercase tracking-wider">Tautan Cepat</h4>
            <ul class="space-y-3 text-sm">
                <li><a href="{{ route('products.index') }}" class="text-stone-400 hover:text-amber-400 transition">Produk</a></li>
                <li><a href="{{ route('blog.index') }}" class="text-stone-400 hover:text-amber-400 transition">Blog</a></li>
                <li><a href="{{ route('contact.index') }}" class="text-stone-400 hover:text-amber-400 transition">Kontak</a></li>
            </ul>
        </div>

        <div>
            <h4 class="text-white font-semibold mb-4 text-sm uppercase tracking-wider">Hubungi Kami</h4>
            <ul class="space-y-3 text-sm text-stone-400">
                <li class="flex items-start gap-2.5"><i class="fa-solid fa-envelope w-4 mt-1 text-amber-500"></i> {{ $settings['email'] ?? '-' }}</li>
                <li class="flex items-start gap-2.5"><i class="fa-solid fa-phone w-4 mt-1 text-amber-500"></i> {{ $settings['phone'] ?? '-' }}</li>
                <li class="flex items-start gap-2.5"><i class="fa-solid fa-location-dot w-4 mt-1 text-amber-500"></i> {{ $settings['address'] ?? '-' }}</li>
            </ul>
        </div>
    </div>

    <div class="border-t border-stone-800 py-5 text-center text-xs text-stone-500">
        &copy; {{ date('Y') }} {{ $settings['site_name'] ?? 'Arinna Hidayah Bakery' }}. Semua hak dilindungi.
    </div>
</footer>
