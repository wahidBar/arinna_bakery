@extends('layouts.app')

@section('title', 'Arinna Hidayah Bakery — Fresh Baked Everyday')

@section('content')

{{-- Hero + Top search/banner area --}}
<section class="bg-gradient-to-b from-amber-100/60 to-[#FFFBF3]">
    <div class="max-w-7xl mx-auto px-4 py-10">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 items-stretch">
            <div class="lg:col-span-2">
                @if($sliders->count())
                <div id="hero-slider" class="relative overflow-hidden rounded-3xl h-64 md:h-96 shadow-sm">
                    @foreach($sliders as $i => $slider)
                        <a href="{{ $slider->link ?? '#' }}" class="slide absolute inset-0 transition-opacity duration-700 {{ $i === 0 ? 'opacity-100' : 'opacity-0 pointer-events-none' }}">
                            <img src="{{ asset('storage/' . $slider->image) }}" alt="{{ $slider->title }}" class="w-full h-full object-cover">
                            @if($slider->title)
                                <div class="absolute inset-0 bg-gradient-to-r from-stone-900/60 via-stone-900/20 to-transparent flex items-center">
                                    <div class="max-w-4xl mx-auto px-8 text-white">
                                        <span class="inline-block text-xs font-bold uppercase tracking-widest text-amber-300 mb-2">Baru dipanggang</span>
                                        <h2 class="font-display text-2xl md:text-4xl font-bold">{{ $slider->title }}</h2>
                                        @if($slider->subtitle)
                                            <p class="mt-2 text-sm md:text-base text-stone-100">{{ $slider->subtitle }}</p>
                                        @endif
                                        <div class="mt-5">
                                            <span class="inline-block bg-amber-700 hover:bg-amber-800 text-white px-5 py-2.5 rounded-full font-semibold text-sm shadow-sm transition">Belanja Sekarang</span>
                                        </div>
                                    </div>
                                </div>
                            @endif
                        </a>
                    @endforeach
                </div>
                @endif
            </div>

            <div class="hidden lg:block">
                <div class="bg-white rounded-3xl p-5 shadow-sm border border-amber-100 h-full flex flex-col justify-between">
                    <div>
                        <p class="font-display text-lg font-semibold text-stone-900 mb-3">Cari Produk</p>
                        <form action="{{ route('products.index') }}" method="GET" class="flex flex-col gap-2.5">
                            <select name="category" class="w-full border border-amber-100 bg-amber-50/60 rounded-full px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400">
                                <option value="">Semua Kategori</option>
                                @foreach(\App\Models\Category::where('is_active', true)->orderBy('sort_order')->take(50)->get() as $cat)
                                    <option value="{{ $cat->slug }}">{{ $cat->name }}</option>
                                @endforeach
                            </select>
                            <div class="flex gap-2">
                                <input type="text" name="q" placeholder="Cari produk..." class="flex-1 border border-amber-100 rounded-full px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400">
                                <button class="bg-amber-700 hover:bg-amber-800 text-white w-11 h-11 flex items-center justify-center rounded-full shrink-0 transition">
                                    <i class="fa-solid fa-magnifying-glass text-sm"></i>
                                </button>
                            </div>
                        </form>
                    </div>

                    <div class="mt-6 pt-5 border-t border-amber-100 flex items-center gap-3">
                        <span class="w-10 h-10 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center">
                            <i class="fa-solid fa-headset"></i>
                        </span>
                        <div>
                            <p class="text-xs text-stone-500">Butuh bantuan?</p>
                            <p class="text-sm font-semibold text-stone-800">+62 812-3456-7890</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<main class="max-w-7xl mx-auto px-4 py-14 space-y-16">

    {{-- Category picks --}}
    <section>
        <div class="mb-6">
            <span class="text-amber-600 font-semibold tracking-widest uppercase text-xs">Jelajahi</span>
            <h2 class="font-display text-2xl font-bold text-stone-900 mt-1">Kategori Pilihan</h2>
        </div>
        <div class="grid grid-cols-3 md:grid-cols-6 gap-4">
            @foreach(\App\Models\Category::where('is_active', true)->orderBy('sort_order')->take(12)->get() as $category)
                <a href="{{ route('products.index', ['category' => $category->slug]) }}" class="flex flex-col items-center gap-2.5 bg-white rounded-2xl border border-amber-100 p-4 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition text-center">
                    <div class="w-12 h-12 rounded-full bg-amber-100 flex items-center justify-center text-amber-700 font-display font-bold">{{ mb_substr($category->name,0,1) }}</div>
                    <span class="text-xs font-semibold text-stone-600">{{ $category->name }}</span>
                </a>
            @endforeach
        </div>
    </section>

    {{-- Banner blocks (promos) --}}
    <section class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="lg:col-span-2 bg-amber-100/70 rounded-3xl p-8 flex items-center gap-6 relative overflow-hidden">
            <div class="relative z-10">
                <div class="text-xs uppercase text-amber-800 font-bold tracking-widest">100% Bahan Alami</div>
                <h3 class="font-display text-2xl md:text-4xl font-bold mt-2 text-stone-900">Smoothie &amp; Jus Segar</h3>
                <p class="mt-2 text-stone-700 text-sm">Dibuat dari buah pilihan — segar dan menyehatkan setiap hari.</p>
                <a href="{{ route('products.index') }}" class="inline-block mt-5 bg-white text-amber-700 px-5 py-2.5 rounded-full font-semibold text-sm shadow-sm hover:bg-amber-50 transition">Belanja Sekarang</a>
            </div>
            <div class="ml-auto hidden md:block relative z-10">
                <img src="{{ asset('images/product-thumb-1.png') }}" alt="hero" class="w-56 drop-shadow-xl">
            </div>
        </div>

        <div class="bg-white rounded-3xl p-6 shadow-sm border border-amber-100 flex flex-col justify-between">
            <div>
                <div class="text-xs text-amber-600 font-bold uppercase tracking-widest">Diskon 20%</div>
                <h4 class="font-display mt-2 font-bold text-lg text-stone-900">Buah &amp; Sayur</h4>
            </div>
            <a href="{{ route('products.index') }}" class="mt-4 inline-flex items-center gap-2 text-amber-700 font-semibold text-sm">Lihat Koleksi <i class="fa-solid fa-arrow-right text-xs"></i></a>
        </div>

        <div class="bg-white rounded-3xl p-6 shadow-sm border border-amber-100 flex flex-col justify-between">
            <div>
                <div class="text-xs text-amber-600 font-bold uppercase tracking-widest">Diskon 15%</div>
                <h4 class="font-display mt-2 font-bold text-lg text-stone-900">Produk Panggangan</h4>
            </div>
            <a href="{{ route('products.index') }}" class="mt-4 inline-flex items-center gap-2 text-amber-700 font-semibold text-sm">Lihat Koleksi <i class="fa-solid fa-arrow-right text-xs"></i></a>
        </div>
    </section>

    {{-- Featured / Newest products --}}
    @if($featuredProducts->count())
    <section>
        <div class="flex items-center justify-between mb-6">
            <div>
                <span class="text-amber-600 font-semibold tracking-widest uppercase text-xs">Terlaris</span>
                <h2 class="font-display text-2xl font-bold text-stone-900 mt-1">Produk Unggulan</h2>
            </div>
            <a href="{{ route('products.index') }}" class="text-amber-700 font-semibold text-sm hover:text-amber-800">Lihat Semua →</a>
        </div>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-5">
            @foreach($featuredProducts as $product)
                <x-product-card :product="$product" />
            @endforeach
        </div>
    </section>
    @endif

    @if($newestProducts->count())
    <section>
        <div class="mb-6">
            <span class="text-amber-600 font-semibold tracking-widest uppercase text-xs">Baru Tiba</span>
            <h2 class="font-display text-2xl font-bold text-stone-900 mt-1">Produk Terbaru</h2>
        </div>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-5">
            @foreach($newestProducts as $product)
                <x-product-card :product="$product" />
            @endforeach
        </div>
    </section>
    @endif

    {{-- Blogs --}}
    @if($latestBlogs->count())
    <section>
        <div class="flex items-center justify-between mb-6">
            <div>
                <span class="text-amber-600 font-semibold tracking-widest uppercase text-xs">Cerita Kami</span>
                <h2 class="font-display text-2xl font-bold text-stone-900 mt-1">Artikel Terbaru</h2>
            </div>
            <a href="{{ route('blog.index') }}" class="text-amber-700 font-semibold text-sm hover:text-amber-800">Lihat Semua →</a>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            @foreach($latestBlogs as $blog)
                <article class="bg-white rounded-2xl border border-amber-100 shadow-sm hover:shadow-lg transition overflow-hidden group">
                    <div class="h-40 overflow-hidden">
                        <img src="{{ asset('storage/' . $blog->thumbnail) }}" alt="{{ $blog->title }}" class="w-full h-full object-cover group-hover:scale-105 transition duration-300">
                    </div>
                    <div class="p-5">
                        <p class="text-xs text-stone-400 font-medium">{{ $blog->published_at?->format('d M Y') }}</p>
                        <h3 class="font-display font-semibold mt-2 text-stone-900">{{ $blog->title }}</h3>
                        <a href="{{ route('blog.show', $blog->slug) }}" class="mt-3 inline-flex items-center gap-2 text-amber-700 font-semibold text-sm">Baca <i class="fa-solid fa-arrow-right text-xs"></i></a>
                    </div>
                </article>
            @endforeach
        </div>
    </section>
    @endif

    {{-- Newsletter / CTA --}}
    <section class="bg-stone-900 rounded-3xl p-8 md:p-10 flex flex-col md:flex-row items-center gap-6 relative overflow-hidden">
        <div class="flex-1 relative z-10">
            <h3 class="font-display text-2xl md:text-3xl font-bold text-white">Dapatkan <span class="text-amber-400">Diskon 25%</span> untuk pembelian pertama</h3>
            <p class="mt-2 text-stone-300 text-sm">Berlangganan newsletter kami untuk info promo & resep terbaru.</p>
        </div>
        <form action="#" method="POST" class="flex gap-2 w-full md:w-auto relative z-10">
            <input type="email" name="email" placeholder="you@mail.com" class="px-4 py-3 rounded-full border-0 flex-1 md:w-64 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400">
            <button class="bg-amber-700 hover:bg-amber-800 text-white px-6 py-3 rounded-full font-semibold text-sm shrink-0 transition">Kirim</button>
        </form>
    </section>

    {{-- Helpful features row --}}
    <section>
        <div class="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-5 gap-5">
            <div class="bg-white rounded-2xl p-5 text-center shadow-sm border border-amber-100">
                <div class="w-11 h-11 mx-auto rounded-full bg-amber-100 text-amber-700 flex items-center justify-center mb-3"><i class="fa-solid fa-truck-fast"></i></div>
                <h4 class="font-display font-bold text-sm text-stone-900">Pengiriman Gratis</h4><p class="text-xs text-stone-500 mt-1">Untuk order di atas Rp 200rb</p>
            </div>
            <div class="bg-white rounded-2xl p-5 text-center shadow-sm border border-amber-100">
                <div class="w-11 h-11 mx-auto rounded-full bg-amber-100 text-amber-700 flex items-center justify-center mb-3"><i class="fa-solid fa-shield-halved"></i></div>
                <h4 class="font-display font-bold text-sm text-stone-900">Pembayaran Aman</h4><p class="text-xs text-stone-500 mt-1">100% terjamin aman</p>
            </div>
            <div class="bg-white rounded-2xl p-5 text-center shadow-sm border border-amber-100">
                <div class="w-11 h-11 mx-auto rounded-full bg-amber-100 text-amber-700 flex items-center justify-center mb-3"><i class="fa-solid fa-award"></i></div>
                <h4 class="font-display font-bold text-sm text-stone-900">Jaminan Kualitas</h4><p class="text-xs text-stone-500 mt-1">Kami jamin setiap produk</p>
            </div>
            <div class="bg-white rounded-2xl p-5 text-center shadow-sm border border-amber-100">
                <div class="w-11 h-11 mx-auto rounded-full bg-amber-100 text-amber-700 flex items-center justify-center mb-3"><i class="fa-solid fa-tags"></i></div>
                <h4 class="font-display font-bold text-sm text-stone-900">Promo Harian</h4><p class="text-xs text-stone-500 mt-1">Hemat lebih setiap hari</p>
            </div>
            <div class="bg-white rounded-2xl p-5 text-center shadow-sm border border-amber-100">
                <div class="w-11 h-11 mx-auto rounded-full bg-amber-100 text-amber-700 flex items-center justify-center mb-3"><i class="fa-solid fa-headset"></i></div>
                <h4 class="font-display font-bold text-sm text-stone-900">Dukungan 24/7</h4><p class="text-xs text-stone-500 mt-1">Kami siap membantu</p>
            </div>
        </div>
    </section>

</main>

@endsection

@push('scripts')
<script>
// Auto-play hero slider sederhana
let currentSlide = 0;
const slides = document.querySelectorAll('#hero-slider .slide');
if (slides.length > 1) {
        setInterval(() => {
                slides[currentSlide].classList.replace('opacity-100', 'opacity-0');
                currentSlide = (currentSlide + 1) % slides.length;
                slides[currentSlide].classList.replace('opacity-0', 'opacity-100');
        }, 4000);
}

// Tambah ke keranjang tanpa reload (dipakai oleh x-product-card)
function quickAddToCart(productId) {
        fetch("{{ route('cart.store') }}", {
                method: 'POST',
                headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                },
                body: JSON.stringify({ product_id: productId, qty: 1 }),
        })
        .then(res => res.json().then(data => ({ status: res.status, data })))
        .then(({ status, data }) => {
                if (status === 422) {
                        alert(data.message);
                        return;
                }
                if (status === 401) {
                        window.location.href = "{{ route('login') }}";
                        return;
                }
                if (typeof refreshCartBadge === 'function') refreshCartBadge();
        });
}
</script>
@endpush
