@props(['product'])

<div class="bg-white rounded-2xl border border-amber-100 shadow-sm hover:shadow-lg hover:-translate-y-0.5 transition duration-300 overflow-hidden group">
    <a href="{{ route('products.show', $product->slug) }}" class="block relative">
        <div class="h-44 overflow-hidden bg-amber-50">
            <img
                src="{{ $product->primaryImage ? asset('storage/' . $product->primaryImage->image_path) : asset('images/placeholder.jpg') }}"
                alt="{{ $product->name }}"
                class="w-full h-full object-cover group-hover:scale-105 transition duration-300"
            >
        </div>

        <div class="absolute top-3 left-3 flex flex-col gap-1.5">
            @if ($product->is_new)
                <span class="bg-emerald-600 text-white text-[10px] font-bold uppercase tracking-wide px-2.5 py-1 rounded-full shadow-sm">Baru</span>
            @endif
            @if ($product->discount_price)
                <span class="bg-rose-600 text-white text-[10px] font-bold uppercase tracking-wide px-2.5 py-1 rounded-full shadow-sm">Diskon</span>
            @endif
        </div>
    </a>

    <div class="p-4">
        <p class="text-[11px] font-semibold text-amber-600 uppercase tracking-wide mb-1">{{ $product->category->name ?? '' }}</p>
        <a href="{{ route('products.show', $product->slug) }}">
            <h3 class="font-display font-semibold text-sm text-stone-900 line-clamp-2 mb-2 hover:text-amber-700 transition">
                {{ $product->name }}
            </h3>
        </a>

        <div class="flex items-baseline gap-2 mb-3.5">
            @if ($product->discount_price)
                <span class="text-amber-700 font-bold">Rp {{ number_format($product->discount_price, 0, ',', '.') }}</span>
                <span class="text-xs text-stone-400 line-through">Rp {{ number_format($product->price, 0, ',', '.') }}</span>
            @else
                <span class="text-amber-700 font-bold">Rp {{ number_format($product->price, 0, ',', '.') }}</span>
            @endif
        </div>

        <div class="flex gap-2">
            <a href="{{ route('products.show', $product->slug) }}"
               class="flex-1 text-center text-xs font-semibold border-2 border-amber-700 text-amber-700 rounded-full py-2 hover:bg-amber-50 transition">
                Detail
            </a>
            <button
                type="button"
                onclick="quickAddToCart({{ $product->id }})"
                class="flex-1 text-xs font-semibold bg-amber-700 text-white rounded-full py-2 hover:bg-amber-800 shadow-sm transition">
                + Keranjang
            </button>
        </div>
    </div>
</div>
