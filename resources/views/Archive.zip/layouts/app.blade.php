<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Arinna Hidayah Bakery')</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    @vite(['resources/css/app.css', 'resources/js/app.ts'])
    <style>
        .font-display { font-family: 'Fraunces', ui-serif, Georgia, serif; }
        body { font-family: 'Plus Jakarta Sans', ui-sans-serif, system-ui, sans-serif; }
    </style>
    @stack('head')
</head>
<body class="bg-[#FFFBF3] text-stone-800 antialiased">

    @include('partials.header')

    <main class="min-h-screen">
        @if (session('success'))
            <div class="max-w-7xl mx-auto px-4 mt-4">
                <div class="flex items-center gap-3 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-2xl px-5 py-3.5">
                    <i class="fa-solid fa-circle-check text-emerald-500"></i>
                    <span class="text-sm font-medium">{{ session('success') }}</span>
                </div>
            </div>
        @endif

        @if (session('error'))
            <div class="max-w-7xl mx-auto px-4 mt-4">
                <div class="flex items-center gap-3 bg-rose-50 text-rose-800 border border-rose-200 rounded-2xl px-5 py-3.5">
                    <i class="fa-solid fa-circle-exclamation text-rose-500"></i>
                    <span class="text-sm font-medium">{{ session('error') }}</span>
                </div>
            </div>
        @endif

        @yield('content')
    </main>

    @include('partials.footer')

    @stack('scripts')
</body>
</html>
