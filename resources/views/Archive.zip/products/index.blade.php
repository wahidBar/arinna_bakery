@extends('layouts.app')

@section('title', 'Semua Produk — Arinna Hidayah Bakery')

@section('content')
<div class="bg-amber-50/50 border-b border-amber-100">
    <div class="max-w-7xl mx-auto px-4 py-8">
        <span class="text-amber-600 font-semibold tracking-widest uppercase text-xs">Katalog</span>
        <h1 class="font-display text-3xl font-bold text-stone-900 mt-1">Semua Produk</h1>
    </div>
</div>

<div class="max-w-7xl mx-auto px-4 py-10 grid grid-cols-1 lg:grid-cols-4 gap-8">

    {{-- Sidebar filter --}}
    <aside class="lg:col-span-1">
        <form id="filter-form" method="GET" action="{{ route('products.index') }}" class="bg-white rounded-2xl border border-amber-100 shadow-sm p-5 space-y-6">

            <div>
                <h3 class="font-display font-semibold text-sm mb-3 text-stone-900">Kategori</h3>
                <div class="space-y-2.5 max-h-56 overflow-y-auto pr-1">
                    @foreach ($categories as $category)
                        <label class="flex items-center gap-2.5 text-sm text-stone-600">
                            <input
                                type="checkbox"
                                name="category_arr[]"
                                value="{{ $category->slug }}"
                                class="filter-category rounded border-amber-200 text-amber-700 focus:ring-amber-500"
                                {{ in_array($category->slug, explode(',', request('category', ''))) ? 'checked' : '' }}
                            >
                            {{ $category->name }}
                        </label>
                    @endforeach
                </div>
            </div>

            <div>
                <h3 class="font-display font-semibold text-sm mb-3 text-stone-900">Rentang Harga</h3>
                <div class="flex gap-2">
                    <input type="number" name="min_price" placeholder="Min" value="{{ request('min_price') }}"
                           class="w-1/2 border border-amber-100 rounded-full px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400">
                    <input type="number" name="max_price" placeholder="Max" value="{{ request('max_price') }}"
                           class="w-1/2 border border-amber-100 rounded-full px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400">
                </div>
            </div>

            <div>
                <label class="flex items-center gap-2.5 text-sm text-stone-600">
                    <input type="checkbox" name="discount_only" value="1" class="rounded border-amber-200 text-amber-700 focus:ring-amber-500"
                           {{ request('discount_only') ? 'checked' : '' }}>
                    Hanya produk diskon
                </label>
            </div>

            {{-- Hidden input hasil gabungan checkbox kategori, diisi oleh JS sebelum submit --}}
            <input type="hidden" name="category" id="category-hidden">

            <button type="submit" class="w-full bg-amber-700 text-white text-sm font-semibold rounded-full py-2.5 hover:bg-amber-800 shadow-sm transition">
                Terapkan Filter
            </button>
        </form>
    </aside>

    {{-- Grid produk --}}
    <div class="lg:col-span-3">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
            <div class="relative w-full sm:w-72">
                <i class="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-stone-400 text-xs"></i>
                <input
                    type="text"
                    id="live-search"
                    placeholder="Cari produk di katalog..."
                    value="{{ request('q') }}"
                    class="w-full border border-amber-100 rounded-full pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
                >
            </div>

            <select id="sort-select" class="border border-amber-100 rounded-full px-4 py-2.5 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-amber-400">
                <option value="terbaru" {{ request('sort') === 'terbaru' ? 'selected' : '' }}>Terbaru</option>
                <option value="termurah" {{ request('sort') === 'termurah' ? 'selected' : '' }}>Termurah</option>
                <option value="termahal" {{ request('sort') === 'termahal' ? 'selected' : '' }}>Termahal</option>
                <option value="terlaris" {{ request('sort') === 'terlaris' ? 'selected' : '' }}>Terlaris</option>
            </select>
        </div>

        <div id="product-grid">
            @include('products.partials.grid', ['products' => $products])
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
// Gabungkan checkbox kategori jadi 1 query string sebelum submit form
document.getElementById('filter-form').addEventListener('submit', function () {
    const checked = Array.from(document.querySelectorAll('.filter-category:checked')).map(el => el.value);
    document.getElementById('category-hidden').value = checked.join(',');
});

// Live search & sort tanpa reload, hasil masuk ke #product-grid
function reloadGrid() {
    const params = new URLSearchParams(window.location.search);
    const q = document.getElementById('live-search').value;
    const sort = document.getElementById('sort-select').value;

    if (q) params.set('q', q); else params.delete('q');
    params.set('sort', sort);

    fetch(`{{ route('products.index') }}?${params.toString()}`, {
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
    })
    .then(res => res.text())
    .then(html => {
        document.getElementById('product-grid').innerHTML = html;
        window.history.pushState({}, '', `{{ route('products.index') }}?${params.toString()}`);
    });
}

let searchDebounce;
document.getElementById('live-search').addEventListener('input', function () {
    clearTimeout(searchDebounce);
    searchDebounce = setTimeout(reloadGrid, 400);
});
document.getElementById('sort-select').addEventListener('change', reloadGrid);

// Quick add to cart dari grid produk
function quickAddToCart(productId) {
    fetch("{{ route('cart.store') }}", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
        },
        body: JSON.stringify({ product_id: productId, qty: 1 }),
    })
    .then(res => res.json().then(data => ({ status: res.status, data })))
    .then(({ status, data }) => {
        if (status === 401) { window.location.href = "{{ route('login') }}"; return; }
        if (status === 422) { alert(data.message); return; }
        refreshCartBadge();
    });
}
</script>
@endpush
