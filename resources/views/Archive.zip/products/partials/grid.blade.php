@if ($products->isEmpty())
    <div class="text-center py-20 text-stone-400 bg-white rounded-2xl border border-amber-100">
        <i class="fa-solid fa-croissant text-3xl text-amber-200 mb-3"></i>
        <p class="text-sm font-medium">Produk tidak ditemukan.</p>
    </div>
@else
    <div class="grid grid-cols-2 md:grid-cols-3 gap-5">
        @foreach ($products as $product)
            <x-product-card :product="$product" />
        @endforeach
    </div>

    <div class="mt-8">
        {{ $products->links() }}
    </div>
@endif
