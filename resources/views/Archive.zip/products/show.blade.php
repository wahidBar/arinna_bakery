@extends('layouts.app')

@section('title', $product->name . ' — Arinna Hidayah Bakery')

@section('content')
<div class="max-w-7xl mx-auto px-4 py-10">

    <div class="grid grid-cols-1 md:grid-cols-2 gap-10">

        {{-- Galeri gambar --}}
        <div>
            <div class="rounded-2xl overflow-hidden bg-white border border-amber-100 shadow-sm mb-3">
                <img id="main-image"
                     src="{{ $product->images->first() ? asset('storage/' . $product->images->first()->image_path) : asset('images/placeholder.jpg') }}"
                     alt="{{ $product->name }}"
                     class="w-full h-96 object-cover">
            </div>
            @if ($product->images->count() > 1)
                <div class="flex gap-2.5">
                    @foreach ($product->images as $image)
                        <button type="button" onclick="document.getElementById('main-image').src = '{{ asset('storage/' . $image->image_path) }}'"
                                class="w-16 h-16 rounded-xl overflow-hidden border-2 border-transparent hover:border-amber-500 transition">
                            <img src="{{ asset('storage/' . $image->image_path) }}" class="w-full h-full object-cover">
                        </button>
                    @endforeach
                </div>
            @endif
        </div>

        {{-- Info produk --}}
        <div>
            <p class="text-xs font-bold text-amber-600 uppercase tracking-wide mb-2">{{ $product->category->name ?? '' }}</p>
            <h1 class="font-display text-3xl font-bold text-stone-900 mb-3">{{ $product->name }}</h1>

            <div class="flex items-center gap-2 mb-4">
                <span class="text-amber-500"><i class="fa-solid fa-star"></i></span>
                <span class="text-sm text-stone-600">{{ $product->average_rating }} ({{ $product->reviews_count }} ulasan)</span>
            </div>

            <div class="flex items-baseline gap-3 mb-2">
                @if ($product->discount_price)
                    <span class="text-2xl font-bold text-amber-700">Rp {{ number_format($product->discount_price, 0, ',', '.') }}</span>
                    <span class="text-stone-400 line-through">Rp {{ number_format($product->price, 0, ',', '.') }}</span>
                @else
                    <span class="text-2xl font-bold text-amber-700">Rp {{ number_format($product->price, 0, ',', '.') }}</span>
                @endif
            </div>

            <p class="text-sm text-stone-500 mb-6">
                Stok: {{ $product->stock > 0 ? $product->stock . ' tersedia' : 'Habis' }}
                @if ($product->weight) &middot; {{ $product->weight }} @endif
            </p>

            <form id="add-to-cart-form" class="space-y-5">
                @csrf
                <input type="hidden" name="product_id" value="{{ $product->id }}">

                <div class="flex items-center gap-3">
                    <label class="text-sm font-semibold text-stone-700">Jumlah</label>
                    <div class="flex items-center border border-amber-100 rounded-full bg-white">
                        <button type="button" onclick="stepQty(-1)" class="w-9 h-9 text-stone-500 hover:text-amber-700">-</button>
                        <input type="number" name="qty" id="qty-input" value="1" min="1" max="{{ $product->stock }}"
                               class="w-12 text-center border-0 focus:ring-0 bg-transparent">
                        <button type="button" onclick="stepQty(1)" class="w-9 h-9 text-stone-500 hover:text-amber-700">+</button>
                    </div>
                </div>

                <div class="flex gap-3">
                    <button type="button" onclick="addToCart(false)"
                            class="flex-1 border-2 border-amber-700 text-amber-700 font-semibold rounded-full py-3 hover:bg-amber-50 transition disabled:opacity-40 disabled:cursor-not-allowed"
                            @if($product->stock < 1) disabled @endif>
                        Tambah ke Keranjang
                    </button>
                    <button type="button" onclick="addToCart(true)"
                            class="flex-1 bg-amber-700 text-white font-semibold rounded-full py-3 hover:bg-amber-800 shadow-sm transition disabled:opacity-40 disabled:cursor-not-allowed"
                            @if($product->stock < 1) disabled @endif>
                        Beli Sekarang
                    </button>
                </div>
            </form>
        </div>
    </div>

    {{-- Tabs: Deskripsi, Informasi, Ulasan --}}
    <div class="mt-16" x-data="{ tab: 'deskripsi' }">
        <div class="flex gap-8 border-b border-amber-100 mb-6">
            <button @click="tab = 'deskripsi'" :class="tab === 'deskripsi' ? 'border-amber-700 text-amber-700' : 'border-transparent text-stone-500'"
                    class="pb-3 border-b-2 text-sm font-semibold transition">Deskripsi</button>
            <button @click="tab = 'informasi'" :class="tab === 'informasi' ? 'border-amber-700 text-amber-700' : 'border-transparent text-stone-500'"
                    class="pb-3 border-b-2 text-sm font-semibold transition">Informasi</button>
            <button @click="tab = 'ulasan'" :class="tab === 'ulasan' ? 'border-amber-700 text-amber-700' : 'border-transparent text-stone-500'"
                    class="pb-3 border-b-2 text-sm font-semibold transition">Ulasan ({{ $product->reviews_count }})</button>
        </div>

        <div x-show="tab === 'deskripsi'" class="text-sm text-stone-600 leading-relaxed">
            {{ $product->description ?: 'Belum ada deskripsi untuk produk ini.' }}
        </div>

        <div x-show="tab === 'informasi'" x-cloak class="text-sm text-stone-600 leading-relaxed">
            {{ $product->information ?: 'Belum ada informasi tambahan.' }}
        </div>

        <div x-show="tab === 'ulasan'" x-cloak class="space-y-6">
            @forelse ($reviews as $review)
                <div class="border-b border-amber-100 pb-5">
                    <div class="flex items-center gap-2 mb-1.5">
                        <span class="font-semibold text-sm text-stone-800">{{ $review->user->name }}</span>
                        <span class="text-amber-500 text-sm">{{ str_repeat('★', $review->rating) }}{{ str_repeat('☆', 5 - $review->rating) }}</span>
                    </div>
                    @if ($review->comment)
                        <p class="text-sm text-stone-600">{{ $review->comment }}</p>
                    @endif
                    @if ($review->photo)
                        <img src="{{ asset('storage/' . $review->photo) }}" class="w-20 h-20 object-cover rounded-xl mt-2">
                    @endif
                </div>
            @empty
                <p class="text-sm text-stone-400">Belum ada ulasan untuk produk ini.</p>
            @endforelse

            {{ $reviews->links() }}

            {{-- Form kirim ulasan, hanya muncul untuk user yang sudah login & pernah membeli --}}
            @auth
                @if ($canReview)
                    <form method="POST" action="{{ route('products.reviews.store', $product) }}" enctype="multipart/form-data" class="bg-white rounded-2xl border border-amber-100 shadow-sm p-5 mt-6 space-y-3">
                        @csrf
                        <h4 class="font-display font-semibold text-sm text-stone-900">Tulis Ulasan Anda</h4>

                        {{-- order_item_id sebaiknya dipilih dari dropdown pesanan `selesai` milik user untuk produk ini --}}
                        <select name="order_item_id" class="w-full border border-amber-100 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400" required>
                            <option value="">Pilih pesanan yang mau diulas</option>
                            @foreach (auth()->user()->orders()->where('status', 'selesai')->with('items')->get() as $order)
                                @foreach ($order->items->where('product_id', $product->id) as $item)
                                    <option value="{{ $item->id }}">{{ $order->invoice_no }} — {{ $order->created_at->format('d M Y') }}</option>
                                @endforeach
                            @endforeach
                        </select>

                        <select name="rating" class="w-full border border-amber-100 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400" required>
                            <option value="">Rating</option>
                            @for ($i = 5; $i >= 1; $i--)
                                <option value="{{ $i }}">{{ $i }} Bintang</option>
                            @endfor
                        </select>

                        <textarea name="comment" rows="3" placeholder="Bagikan pengalaman Anda..."
                                  class="w-full border border-amber-100 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"></textarea>

                        <input type="file" name="photo" accept="image/*" class="text-sm">

                        <button type="submit" class="bg-amber-700 text-white text-sm font-semibold rounded-full px-6 py-2.5 hover:bg-amber-800 shadow-sm transition">
                            Kirim Ulasan
                        </button>
                    </form>
                @endif
            @endauth
        </div>
    </div>

    {{-- Produk terkait --}}
    @if ($relatedProducts->count())
    <div class="mt-16">
        <span class="text-amber-600 font-semibold tracking-widest uppercase text-xs">Rekomendasi</span>
        <h2 class="font-display text-2xl font-bold text-stone-900 mt-1 mb-6">Produk Terkait</h2>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-5">
            @foreach ($relatedProducts as $related)
                <x-product-card :product="$related" />
            @endforeach
        </div>
    </div>
    @endif
</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
<script>
function stepQty(delta) {
    const input = document.getElementById('qty-input');
    const newVal = Math.max(1, parseInt(input.value || 1) + delta);
    input.value = Math.min(newVal, parseInt(input.max || 999));
}

function addToCart(redirectToCheckout) {
    const qty = document.getElementById('qty-input').value;

    fetch("{{ route('cart.store') }}", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
        },
        body: JSON.stringify({ product_id: {{ $product->id }}, qty: qty }),
    })
    .then(res => res.json().then(data => ({ status: res.status, data })))
    .then(({ status, data }) => {
        if (status === 401) { window.location.href = "{{ route('login') }}"; return; }
        if (status === 422) { alert(data.message); return; }

        refreshCartBadge();

        if (redirectToCheckout) {
            window.location.href = "{{ route('checkout.index') }}";
        } else {
            alert('Produk ditambahkan ke keranjang!');
        }
    });
}
</script>
@endpush
