@extends('layouts.admin')

@section('title', 'Tambah Produk')

@section('content')
<form method="POST" action="{{ route('admin.products.store') }}" enctype="multipart/form-data" class="max-w-3xl">
    @csrf

    <div class="bg-white rounded-2xl border border-amber-100 shadow-sm p-6 space-y-5">

        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="text-sm font-semibold text-stone-700 block mb-1.5">Nama Produk</label>
                <input type="text" name="name" value="{{ old('name') }}" class="w-full border border-amber-100 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400" required>
                @error('name') <p class="text-xs text-rose-600 mt-1">{{ $message }}</p> @enderror
            </div>
            <div>
                <label class="text-sm font-semibold text-stone-700 block mb-1.5">Slug (kosongkan untuk auto-generate)</label>
                <input type="text" name="slug" value="{{ old('slug') }}" class="w-full border border-amber-100 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400">
            </div>
        </div>

        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="text-sm font-semibold text-stone-700 block mb-1.5">Kategori</label>
                <select name="category_id" class="w-full border border-amber-100 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400" required>
                    <option value="">Pilih kategori</option>
                    @foreach ($categories as $category)
                        <option value="{{ $category->id }}" {{ old('category_id') == $category->id ? 'selected' : '' }}>{{ $category->name }}</option>
                    @endforeach
                </select>
                @error('category_id') <p class="text-xs text-rose-600 mt-1">{{ $message }}</p> @enderror
            </div>
            <div>
                <label class="text-sm font-semibold text-stone-700 block mb-1.5">SKU</label>
                <input type="text" name="sku" value="{{ old('sku') }}" class="w-full border border-amber-100 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400" required>
                @error('sku') <p class="text-xs text-rose-600 mt-1">{{ $message }}</p> @enderror
            </div>
        </div>

        <div class="grid grid-cols-3 gap-4">
            <div>
                <label class="text-sm font-semibold text-stone-700 block mb-1.5">Harga Normal</label>
                <input type="number" name="price" value="{{ old('price') }}" class="w-full border border-amber-100 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400" required>
                @error('price') <p class="text-xs text-rose-600 mt-1">{{ $message }}</p> @enderror
            </div>
            <div>
                <label class="text-sm font-semibold text-stone-700 block mb-1.5">Harga Diskon (opsional)</label>
                <input type="number" name="discount_price" value="{{ old('discount_price') }}" class="w-full border border-amber-100 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400">
                @error('discount_price') <p class="text-xs text-rose-600 mt-1">{{ $message }}</p> @enderror
            </div>
            <div>
                <label class="text-sm font-semibold text-stone-700 block mb-1.5">Stok</label>
                <input type="number" name="stock" value="{{ old('stock', 0) }}" class="w-full border border-amber-100 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400" required>
            </div>
        </div>

        <div>
            <label class="text-sm font-semibold text-stone-700 block mb-1.5">Berat / Satuan</label>
            <input type="text" name="weight" value="{{ old('weight') }}" placeholder="contoh: 250 gram"
                   class="w-full border border-amber-100 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400">
        </div>

        <div>
            <label class="text-sm font-semibold text-stone-700 block mb-1.5">Deskripsi</label>
            <textarea name="description" rows="4" class="w-full border border-amber-100 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400">{{ old('description') }}</textarea>
        </div>

        <div>
            <label class="text-sm font-semibold text-stone-700 block mb-1.5">Informasi Tambahan (komposisi/varian)</label>
            <textarea name="information" rows="3" class="w-full border border-amber-100 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400">{{ old('information') }}</textarea>
        </div>

        <div>
            <label class="text-sm font-semibold text-stone-700 block mb-1.5">Upload Gambar (bisa lebih dari 1, klik gambar untuk jadikan utama)</label>
            <input type="file" name="images[]" id="image-input" accept="image/*" multiple
                   class="w-full border border-amber-100 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400">
            <div id="image-preview" class="grid grid-cols-4 gap-3 mt-3"></div>
            <input type="hidden" name="primary_image_index" id="primary-image-index" value="0">
            @error('images') <p class="text-xs text-rose-600 mt-1">{{ $message }}</p> @enderror
        </div>

        <div class="flex gap-6">
            <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" value="1" checked> Aktif</label>
            <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_featured" value="1"> Featured</label>
            <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_new" value="1"> Produk Baru</label>
        </div>
    </div>

    <div class="mt-6 flex gap-3">
        <button type="submit" class="bg-amber-700 text-white text-sm font-semibold rounded-full px-6 py-2.5 hover:bg-amber-800 shadow-sm transition">Simpan Produk</button>
        <a href="{{ route('admin.products.index') }}" class="text-sm text-stone-500 self-center">Batal</a>
    </div>
</form>
@endsection

@push('scripts')
<script>
// Preview gambar yang dipilih + pilih gambar utama dengan klik
document.getElementById('image-input').addEventListener('change', function (e) {
    const preview = document.getElementById('image-preview');
    preview.innerHTML = '';

    Array.from(e.target.files).forEach((file, index) => {
        const reader = new FileReader();
        reader.onload = function (evt) {
            const wrapper = document.createElement('div');
            wrapper.className = 'relative cursor-pointer';
            wrapper.innerHTML = `
                <img src="${evt.target.result}" class="w-full h-20 object-cover rounded-lg border-2 ${index === 0 ? 'border-amber-600' : 'border-transparent'}">
                <span class="absolute top-1 left-1 text-xs bg-white/90 px-1.5 rounded ${index === 0 ? '' : 'hidden'} primary-badge">Utama</span>
            `;
            wrapper.addEventListener('click', () => {
                document.getElementById('primary-image-index').value = index;
                document.querySelectorAll('#image-preview img').forEach(img => img.classList.remove('border-amber-600'));
                document.querySelectorAll('#image-preview .primary-badge').forEach(b => b.classList.add('hidden'));
                wrapper.querySelector('img').classList.add('border-amber-600');
                wrapper.querySelector('.primary-badge').classList.remove('hidden');
            });
            preview.appendChild(wrapper);
        };
        reader.readAsDataURL(file);
    });
});
</script>
@endpush
