@extends('layouts.admin')

@section('title', 'Edit Produk')

@section('content')
<form method="POST" action="{{ route('admin.products.update', $product) }}" enctype="multipart/form-data" class="max-w-3xl">
    @csrf
    @method('PUT')

    <div class="bg-white rounded-2xl border border-amber-100 shadow-sm p-6 space-y-5">

        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="text-sm font-semibold text-stone-700 block mb-1.5">Nama Produk</label>
                <input type="text" name="name" value="{{ old('name', $product->name) }}" class="w-full border border-amber-100 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400" required>
                @error('name') <p class="text-xs text-rose-600 mt-1">{{ $message }}</p> @enderror
            </div>
            <div>
                <label class="text-sm font-semibold text-stone-700 block mb-1.5">Slug</label>
                <input type="text" name="slug" value="{{ old('slug', $product->slug) }}" class="w-full border border-amber-100 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400">
            </div>
        </div>

        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="text-sm font-semibold text-stone-700 block mb-1.5">Kategori</label>
                <select name="category_id" class="w-full border border-amber-100 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400" required>
                    @foreach ($categories as $category)
                        <option value="{{ $category->id }}" {{ old('category_id', $product->category_id) == $category->id ? 'selected' : '' }}>{{ $category->name }}</option>
                    @endforeach
                </select>
            </div>
            <div>
                <label class="text-sm font-semibold text-stone-700 block mb-1.5">SKU</label>
                <input type="text" name="sku" value="{{ old('sku', $product->sku) }}" class="w-full border border-amber-100 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400" required>
            </div>
        </div>

        <div class="grid grid-cols-3 gap-4">
            <div>
                <label class="text-sm font-semibold text-stone-700 block mb-1.5">Harga Normal</label>
                <input type="number" name="price" value="{{ old('price', $product->price) }}" class="w-full border border-amber-100 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400" required>
            </div>
            <div>
                <label class="text-sm font-semibold text-stone-700 block mb-1.5">Harga Diskon</label>
                <input type="number" name="discount_price" value="{{ old('discount_price', $product->discount_price) }}" class="w-full border border-amber-100 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400">
            </div>
            <div>
                <label class="text-sm font-semibold text-stone-700 block mb-1.5">Stok</label>
                <input type="number" name="stock" value="{{ old('stock', $product->stock) }}" class="w-full border border-amber-100 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400" required>
            </div>
        </div>

        <div>
            <label class="text-sm font-semibold text-stone-700 block mb-1.5">Berat / Satuan</label>
            <input type="text" name="weight" value="{{ old('weight', $product->weight) }}" class="w-full border border-amber-100 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400">
        </div>

        <div>
            <label class="text-sm font-semibold text-stone-700 block mb-1.5">Deskripsi</label>
            <textarea name="description" rows="4" class="w-full border border-amber-100 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400">{{ old('description', $product->description) }}</textarea>
        </div>

        <div>
            <label class="text-sm font-semibold text-stone-700 block mb-1.5">Informasi Tambahan</label>
            <textarea name="information" rows="3" class="w-full border border-amber-100 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400">{{ old('information', $product->information) }}</textarea>
        </div>

        {{-- Gambar existing --}}
        <div>
            <label class="text-sm font-medium block mb-2">Gambar Saat Ini (klik ⭐ untuk jadikan utama, centang untuk hapus)</label>
            <div class="grid grid-cols-4 gap-3">
                @foreach ($product->images as $image)
                    <div class="relative">
                        <img src="{{ asset('storage/' . $image->image_path) }}"
                             class="w-full h-20 object-cover rounded-lg border-2 {{ $image->is_primary ? 'border-amber-600' : 'border-transparent' }}">
                        <label class="absolute top-1 left-1 bg-white/90 rounded px-1 text-xs flex items-center gap-1">
                            <input type="radio" name="primary_image_id" value="{{ $image->id }}" {{ $image->is_primary ? 'checked' : '' }}> Utama
                        </label>
                        <label class="absolute bottom-1 right-1 bg-white/90 rounded px-1 text-xs flex items-center gap-1 text-rose-600">
                            <input type="checkbox" name="delete_image_ids[]" value="{{ $image->id }}"> Hapus
                        </label>
                    </div>
                @endforeach
            </div>
        </div>

        <div>
            <label class="text-sm font-semibold text-stone-700 block mb-1.5">Tambah Gambar Baru (opsional)</label>
            <input type="file" name="images[]" accept="image/*" multiple class="w-full border border-amber-100 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400">
        </div>

        <div class="flex gap-6">
            <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" value="1" {{ $product->is_active ? 'checked' : '' }}> Aktif</label>
            <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_featured" value="1" {{ $product->is_featured ? 'checked' : '' }}> Featured</label>
            <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_new" value="1" {{ $product->is_new ? 'checked' : '' }}> Produk Baru</label>
        </div>
    </div>

    <div class="mt-6 flex gap-3">
        <button type="submit" class="bg-amber-700 text-white text-sm font-semibold rounded-full px-6 py-2.5 hover:bg-amber-800 shadow-sm transition">Simpan Perubahan</button>
        <a href="{{ route('admin.products.index') }}" class="text-sm text-stone-500 self-center">Batal</a>
    </div>
</form>
@endsection
